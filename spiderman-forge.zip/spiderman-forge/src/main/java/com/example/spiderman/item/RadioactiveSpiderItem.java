package com.example.spiderman.item;

import com.example.spiderman.SpiderPowers;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Right-click to let it bite you. */
public class RadioactiveSpiderItem extends Item {
    public RadioactiveSpiderItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (SpiderPowers.has(player)) {
            if (!level.isClientSide) player.displayClientMessage(Component.translatable("message.spiderman.already"), true);
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) {
            if (player.getHealth() > 4.0f) player.hurt(level.damageSources().magic(), 2.0f);
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.SPIDER_HURT, SoundSource.PLAYERS, 1.0f, 1.0f);
            SpiderPowers.grant(player, true);
        }
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
