package com.example.spiderman;

import com.example.spiderman.effect.SpiderPowersEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, SpiderManMod.MOD_ID);

    public static final RegistryObject<MobEffect> SPIDER_POWERS =
            EFFECTS.register("spider_powers", SpiderPowersEffect::new);
}
