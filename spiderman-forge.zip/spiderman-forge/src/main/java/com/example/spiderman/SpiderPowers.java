package com.example.spiderman;

import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public final class SpiderPowers {
    private SpiderPowers() {}

    public static boolean has(LivingEntity e) {
        return e.hasEffect(ModEffects.SPIDER_POWERS.get());
    }

    public static void grant(Player player, boolean showMessage) {
        if (has(player)) return;
        // duration -1 = infinite
        player.addEffect(new MobEffectInstance(ModEffects.SPIDER_POWERS.get(), -1, 0, false, false, true));
        if (showMessage) player.displayClientMessage(Component.translatable("message.spiderman.bitten"), true);
    }
}
