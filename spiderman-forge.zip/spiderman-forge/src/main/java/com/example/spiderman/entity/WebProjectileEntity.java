package com.example.spiderman.entity;

import com.example.spiderman.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

public class WebProjectileEntity extends ThrowableItemProjectile {
    public static final float DAMAGE = 4.0f;
    public static final boolean PLACE_COBWEBS = true;

    public WebProjectileEntity(EntityType<? extends WebProjectileEntity> type, Level level) {
        super(type, level);
    }

    public WebProjectileEntity(Level level, LivingEntity owner) {
        super(ModEntities.WEB_PROJECTILE.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.COBWEB; // renders as a flying cobweb
    }

    @Override
    protected float getGravity() {
        return 0.01f;
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        target.hurt(damageSources().thrown(this, getOwner()), DAMAGE);
        if (target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 4), getOwner());
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        Level level = level();
        if (!level.isClientSide && PLACE_COBWEBS && level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            BlockPos pos = result.getBlockPos().relative(result.getDirection());
            if (level.getBlockState(pos).canBeReplaced()) {
                level.setBlockAndUpdate(pos, Blocks.COBWEB.defaultBlockState());
            }
        }
    }

    @Override
    protected void onHit(HitResult hit) {
        super.onHit(hit);
        if (!level().isClientSide) {
            discard();
        }
    }
}
