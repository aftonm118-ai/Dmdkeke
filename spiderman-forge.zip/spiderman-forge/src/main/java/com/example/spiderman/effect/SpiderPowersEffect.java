package com.example.spiderman.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** The "you were bitten" status. Infinite duration. Milk removes it (the cure!). */
public class SpiderPowersEffect extends MobEffect {
    public SpiderPowersEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xC8102E);
        addAttributeModifier(Attributes.MOVEMENT_SPEED, "7f3c1b0e-5a2d-4c11-9a7e-1d2b3c4d5e6f",
                0.25, AttributeModifier.Operation.MULTIPLY_TOTAL);
        addAttributeModifier(Attributes.ATTACK_DAMAGE, "2b9d6c44-81f0-4e6a-b3a5-6c7d8e9f0a1b",
                2.0, AttributeModifier.Operation.ADDITION);
    }
}
