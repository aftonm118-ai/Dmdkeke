package com.example.spiderman;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Pendulum-style web swinging. CLIENT SIDE ONLY: the local player's velocity is
 * authoritative on the client. Only the local player ever gets an entry in the map.
 */
public final class WebSwing {
    private static final Map<UUID, Swing> ACTIVE = new HashMap<>();

    private static final class Swing {
        final Vec3 anchor;
        double length;
        Swing(Vec3 anchor, double length) { this.anchor = anchor; this.length = length; }
    }

    private WebSwing() {}

    private static Vec3 center(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.6, 0);
    }

    public static void start(Player player, Vec3 anchor) {
        Vec3 c = center(player);
        ACTIVE.put(player.getUUID(), new Swing(anchor, anchor.distanceTo(c)));
        Vec3 dir = anchor.subtract(c).normalize();
        player.setDeltaMovement(player.getDeltaMovement().add(dir.scale(0.5)).add(0, 0.25, 0));
    }

    /** Called every tick while the web shooter is held down. */
    public static void tick(Level level, LivingEntity user) {
        Swing s = ACTIVE.get(user.getUUID());
        if (s == null) return;

        Vec3 c = center(user);
        Vec3 toAnchor = s.anchor.subtract(c);
        double dist = toAnchor.length();
        if (dist < 1.0) { ACTIVE.remove(user.getUUID()); user.stopUsingItem(); return; }
        Vec3 dir = toAnchor.scale(1.0 / dist);

        s.length = Math.min(s.length, Math.max(dist, 2.0));

        Vec3 v = user.getDeltaMovement();
        if (dist > s.length) {
            double toward = v.dot(dir);
            if (toward < 0) v = v.subtract(dir.scale(toward));
            v = v.add(dir.scale(Math.min((dist - s.length) * 0.2, 0.5)));
        }

        Vec3 look = user.getViewVector(1.0f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() > 1.0E-4) v = v.add(flat.normalize().scale(0.015));

        if (v.length() > 3.0) v = v.normalize().scale(3.0);
        user.setDeltaMovement(v);
        user.fallDistance = 0;

        int n = Math.max(1, (int) (dist / 1.5));
        for (int i = 0; i <= n; i++) {
            Vec3 p = c.lerp(s.anchor, i / (double) n);
            level.addParticle(ParticleTypes.END_ROD, p.x, p.y, p.z, 0, 0, 0);
        }
    }
}
