package com.example.spiderman.item;

import com.example.spiderman.SpiderPowers;
import com.example.spiderman.WebSwing;
import com.example.spiderman.entity.WebProjectileEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class WebShooterItem extends Item {
    private static final double SWING_RANGE = 48.0;

    public WebShooterItem(Properties properties) {
        super(properties);
    }

    @Override
    public int getUseDuration(ItemStack stack) { return 72000; }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.NONE; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!SpiderPowers.has(player)) {
            if (!level.isClientSide) player.displayClientMessage(Component.translatable("message.spiderman.no_powers"), true);
            return InteractionResultHolder.fail(stack);
        }

        // SNEAK + right-click on something in range = start swinging (hold right-click)
        if (player.isShiftKeyDown()) {
            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getViewVector(1.0f).scale(SWING_RANGE));
            BlockHitResult hit = level.clip(new ClipContext(eye, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (hit.getType() == HitResult.Type.BLOCK) {
                if (level.isClientSide) {
                    WebSwing.start(player, hit.getLocation());
                } else {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 1.0f, 1.5f);
                }
                player.startUsingItem(hand);
                return InteractionResultHolder.consume(stack);
            }
        }

        // plain right-click = shoot a web
        if (!level.isClientSide) {
            WebProjectileEntity web = new WebProjectileEntity(level, player);
            web.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 2.5f, 0.5f);
            level.addFreshEntity(web);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.8f, 1.3f);
        }
        player.getCooldowns().addCooldown(this, 8);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remaining) {
        if (!level.isClientSide) return;
        if (!SpiderPowers.has(user)) { user.stopUsingItem(); return; }
        WebSwing.tick(level, user);
    }
}
