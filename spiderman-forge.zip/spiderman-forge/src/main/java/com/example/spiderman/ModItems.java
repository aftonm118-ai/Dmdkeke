package com.example.spiderman;

import com.example.spiderman.item.RadioactiveSpiderItem;
import com.example.spiderman.item.WebShooterItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpiderManMod.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SpiderManMod.MOD_ID);

    public static final RegistryObject<Item> WEB_SHOOTER =
            ITEMS.register("web_shooter", () -> new WebShooterItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> RADIOACTIVE_SPIDER =
            ITEMS.register("radioactive_spider", () -> new RadioactiveSpiderItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.spiderman"))
                    .icon(() -> new ItemStack(WEB_SHOOTER.get()))
                    .displayItems((params, output) -> {
                        output.accept(WEB_SHOOTER.get());
                        output.accept(RADIOACTIVE_SPIDER.get());
                    })
                    .build());
}
