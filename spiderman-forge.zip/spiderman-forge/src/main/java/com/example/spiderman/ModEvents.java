package com.example.spiderman;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpiderManMod.MOD_ID)
public class ModEvents {
    /** Chance a spider (or cave spider) hit gives you powers. */
    public static final float BITE_CHANCE = 0.10f;
    /** Chance a spider drops a Radioactive Spider item. */
    public static final float DROP_CHANCE = 0.10f;

    /**
     * Wall climbing (runs on client AND server): touching a wall while spider-powered
     * pushes you up. Sneak to stick in place.
     */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Player p = event.player;
        if (p.isSpectator() || !p.horizontalCollision || !SpiderPowers.has(p)) return;
        Vec3 m = p.getDeltaMovement();
        p.setDeltaMovement(m.x, p.isShiftKeyDown() ? 0.0 : 0.2, m.z);
        p.fallDistance = 0;
    }

    /** Spider-Man doesn't take fall damage. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player p && SpiderPowers.has(p)) {
            event.setCanceled(true);
        }
    }

    /** Get bitten by a real spider. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof ServerPlayer p
                && event.getSource().getEntity() instanceof Spider
                && !SpiderPowers.has(p)
                && p.getRandom().nextFloat() < BITE_CHANCE) {
            SpiderPowers.grant(p, true);
        }
    }

    /** Spiders sometimes drop the radioactive spider item. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.getType() == EntityType.SPIDER && !victim.level().isClientSide
                && victim.getRandom().nextFloat() < DROP_CHANCE) {
            event.getDrops().add(new ItemEntity(victim.level(), victim.getX(), victim.getY(), victim.getZ(),
                    new ItemStack(ModItems.RADIOACTIVE_SPIDER.get())));
        }
    }

    /** Keep powers after dying. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.isWasDeath() && SpiderPowers.has(event.getOriginal())) {
            SpiderPowers.grant(event.getEntity(), false);
        }
    }
}
