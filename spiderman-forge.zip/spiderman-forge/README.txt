Spider-Man mod for Minecraft 1.20.1 + Forge 47.x
Build: see the chat instructions (GitHub Actions or `gradle build`). Jar ends up in build/libs/.
Test: /effect give @s spiderman:spider_powers infinite
